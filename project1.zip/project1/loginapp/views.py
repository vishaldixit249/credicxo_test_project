from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from django.contrib import messages


# the fuction render the index page
def login(request):
    return render(request,'login.html')

#the fuction authenticate the login credentials and render the page according the user permission
def administrater(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            user1= User.objects.get(username=username)
            if(user1.is_superuser==True and user1.is_staff==True): #condition to check admin
                name = user1.get_full_name()
                username = user1.get_username()
                return render(request,'admin_page.html',{'name':name,'username':username})
            elif(user1.is_superuser==False and user1.is_staff==True): #condition to check teacher
                name = user1.get_full_name()
                username=user1.get_username()
                return render(request, 'teacher_page.html',{'name':name,'username':username})
            else: #condition to check student
                name = user1.get_full_name()
                username = user1.get_username()
                return render(request, 'student_page.html', {'name': name, 'username': username})
        else:
            messages.info(request, 'Invalid Credentials') #if the user insert the invalid login credentials
            return render(request,'login.html')

# this method is to add teacher in data base
def add_teacher(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        password = request.POST['password']
        email = request.POST['email']

        if User.objects.filter(username=username).exists():
            print("username taken")
            messages.info(request, 'Username taken :(')
            return redirect('add_teacher')
        elif User.objects.filter(email=email).exists():
            print("email taken")
            messages.info(request, 'email ID taken :(')
            return redirect('add_teacher')
        else:
            user = User.objects.create_user(username=username, password=password, email=email, first_name=first_name,
                                            last_name=last_name, is_staff=True)
            user.save()
            messages.info(request, 'Teacher added')
            print("teacher is added")
            return redirect("add_teacher")
    else:
        return render(request,'add_teacher.html')

# this method is to add student in database
def add_student(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        password = request.POST['password']
        email = request.POST['email']

        if User.objects.filter(username=username).exists():
            print("username taken")
            messages.info(request, 'Username taken :(')
            return redirect('add_student')
        elif User.objects.filter(email=email).exists():
            print("email taken")
            messages.info(request, 'email ID taken :(')
            return redirect('add_student')
        else:
            user = User.objects.create_user(username=username, password=password, email=email, first_name=first_name,
                                            last_name=last_name, is_staff=False)
            user.save()
            messages.info(request, 'Student added')
            print("student is added")
            return redirect('add_student')

    else:
        return render(request,'add_student.html')

def add_admin(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        password = request.POST['password']
        email = request.POST['email']

        if User.objects.filter(username=username).exists():
            print("username taken")
            messages.info(request, 'Username taken :(')
            return redirect('add_student')
        elif User.objects.filter(email=email).exists():
            print("email taken")
            messages.info(request, 'email ID taken :(')
            return redirect('add_student')
        else:
            user = User.objects.create_user(username=username, password=password, email=email, first_name=first_name,
                                            last_name=last_name, is_superuser=True, is_staff=True)
            user.save()
            messages.info(request, 'Admin added')
            print("Admin is added")
            return redirect('add_admin')

    else:
        return render(request,'add_admin.html')

# this method logout the user and redirect to login page
def logout(request):
    auth.logout(request)
    return redirect('login')

# the fuction reset the password....... of the user
def forget_password(request):
    if request.method == 'POST':
        print("post request received")
        username = request.POST['username']
        password = request.POST['password']
        password1 = request.POST['password1']
        if (password==password1):
            print("password and confirm password is same")
            user1 = User.objects.get(username=username)
            if(user1.get_username()==username):
                user1.set_password(password)
                user1.save()
                messages.info(request,'password reset successfully')
                return redirect('login')
            else:
                messages.info(request, 'Username not found')
                return redirect('forget_password')

        else:
            messages.info(request, 'Password and Confirm password is not same')
            return redirect('forget_password')

    else:
        return render(request, 'forget_password.html')


