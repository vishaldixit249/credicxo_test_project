from django.urls import path
from . import views

urlpatterns = [
    path('', views.login, name='login'),
    path('administrater', views.administrater, name='administrater'),
    path('add_teacher', views.add_teacher, name='add_teacher'),
    path('add_student', views.add_student, name='add_student'),
    path('add_admin', views.add_admin, name='add_admin'),
    path('forget_password', views.forget_password, name='forget_password'),
    path('logout', views.logout, name='logout'),
]