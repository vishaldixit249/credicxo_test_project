step1: extart the zip
step2: open postgre sql server
step3: add DB5 in data base or attached DB5.sql database backup
step4: open cmd 
step5: command to check python = python + enter
step6: command to run django server = python manage.py runserver
step6: command to create intial superuser = python manage.py createsuperuser
	(only when creating new DB file)    - enter username
					    - enter email
					    - enter password
					    - enter confirm password
step7: open localhost in the chrome
step8:login the profile